# Лабораторна робота 4: Inventory App з Room Database

## 📱 Опис проекту

**Lab4App** - це Android-додаток для управління інвентарем товарів з використанням **Room Database** для постійного зберігання даних у SQLite базі даних.

### 🎯 Основні функції:
- ✅ **Автоматичне заповнення БД** - при першому запуску додається 24 записи (12 молочних продуктів + 12 іграшок)
- ✅ Додавання нових товарів вручну (назва, ціна, дата)
- ✅ Перегляд всіх товарів у вигляді списку
- ✅ Видалення всіх товарів з підтвердженням
- ✅ Вибір дати через DatePicker
- ✅ Валідація введених даних (перевірка порожніх полів, коректності ціни)
- ✅ **Автоматичне розпізнавання типу товару** - якщо назва містить "milk", створюється DairyProduct, інакше - Toy
- ✅ **Постійне зберігання в SQLite** через Room Database
- ✅ **Автоматичне оновлення UI** через Kotlin Flow (реактивний підхід)
- ✅ **Збереження даних після закриття** додатка

---

## 🏗️ Архітектура проекту (Clean Architecture)

```
app/
├── ui/                          # 🎨 Presentation Layer
│   └── MainActivity.kt          - UI контролер, lifecycle, listeners
├── adapter/                     
│   └── ProductAdapter.kt        - Адаптер для відображення у ListView
├── domain/                      # 💼 Business Logic Layer
│   └── ProductService.kt        - Бізнес логіка (валідація, визначення типу)
├── data/                        # 📦 Data Layer
│   ├── room/                    # 🗄️ Room Database
│   │   ├── ProductEntity.kt     - @Entity (таблиця БД)
│   │   ├── ProductDao.kt        - @Dao (SQL запити)
│   │   ├── ProductDatabase.kt   - @Database (клас БД + Singleton)
│   │   └── Converters.kt        - Конвертація Entity ↔ Model
│   ├── ProductRepository.kt     - Інтерфейс репозиторію
│   └── RoomProductRepository.kt - Імплементація з Room
└── model/                       # 🎭 Domain Models
    ├── Product.kt               - Базовий абстрактний клас
    ├── DairyProduct.kt          - Молочні продукти
    └── Toy.kt                   - Іграшки
```

---

## 📊 Діаграма архітектури (4 шари)

```
┌──────────────────────────────────────────────────────────────┐
│                    1️⃣ PRESENTATION LAYER                      │
│  ┌──────────────────┐          ┌─────────────────────┐      │
│  │  MainActivity    │──────────▶│  ProductAdapter     │      │
│  │  • UI Logic      │          │  • ViewHolder       │      │
│  │  • Listeners     │          │  • Data Binding     │      │
│  └────────┬─────────┘          └─────────────────────┘      │
└───────────┼───────────────────────────────────────────────────┘
            │ ViewModel / Service
            ▼
┌──────────────────────────────────────────────────────────────┐
│                  2️⃣ BUSINESS LOGIC LAYER                      │
│  ┌──────────────────────────────────────────────────────┐   │
│  │                ProductService                         │   │
│  │  • suspend fun addProduct() → Валідація даних        │   │
│  │  • fun getAll(): Flow → Отримання всіх товарів       │   │
│  │  • suspend fun clear() → Очищення БД                 │   │
│  │  • Визначення типу (Dairy / Toy)                     │   │
│  └────────┬───────────────────────────────────────────┘   │
└───────────┼───────────────────────────────────────────────────┘
            │ Repository Pattern
            ▼
┌──────────────────────────────────────────────────────────────┐
│                     3️⃣ DATA LAYER                             │
│  ┌───────────────────────────────────────────────────┐      │
│  │         ProductRepository (Interface)             │      │
│  │  • fun getAll(): Flow<List<Product>>             │      │
│  │  • suspend fun add(product: Product)             │      │
│  │  • suspend fun clear()                           │      │
│  └───────────────────┬───────────────────────────────┘      │
│                      │ Dependency Inversion                  │
│                      ▼                                       │
│  ┌───────────────────────────────────────────────────┐      │
│  │      RoomProductRepository (Implementation)       │      │
│  │  • Використовує ProductDao                       │      │
│  │  • Конвертує Entity ↔ Model через Converters    │      │
│  │  • Працює з Flow для реактивності                │      │
│  └───────────────────┬───────────────────────────────┘      │
└────────────────────────┼─────────────────────────────────────┘
                         │ Room Annotations
                         ▼
┌──────────────────────────────────────────────────────────────┐
│                  4️⃣ ROOM DATABASE LAYER                       │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │ProductEntity │◀─│ ProductDao   │◀─│ProductDatabase│      │
│  │  @Entity     │  │   @Dao       │  │  @Database    │      │
│  │              │  │              │  │               │      │
│  │ id: Int      │  │ @Query       │  │ Singleton     │      │
│  │ name: String │  │ @Insert      │  │ Builder       │      │
│  │ price: Double│  │ @Delete      │  │ Migration     │      │
│  │ date: String │  │ Flow<>       │  │               │      │
│  │ type: String │  └──────────────┘  └──────────────┘      │
│  └──────────────┘                                            │
│         ▲                                                    │
│         │ SQL Operations                                    │
│         ▼                                                    │
│  ┌─────────────────────────────────────────┐               │
│  │      SQLite Database (Persistent)       │               │
│  │      products table (25+ records)       │               │
│  └─────────────────────────────────────────┘               │
└──────────────────────────────────────────────────────────────┘
```

---

## 🗄️ Структура бази даних

### Таблиця `products`:

```sql
CREATE TABLE products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    price REAL NOT NULL,
    date TEXT NOT NULL,
    type TEXT NOT NULL  -- "DAIRY" або "TOY"
);
```

**Опис полів:**

| Поле  | Тип     | Опис                          | Обмеження           |
|-------|---------|-------------------------------|---------------------|
| id    | INTEGER | Унікальний ідентифікатор      | PRIMARY KEY, AUTO   |
| name  | TEXT    | Назва товару                  | NOT NULL            |
| price | REAL    | Ціна товару (грн)             | NOT NULL, > 0       |
| date  | TEXT    | Дата (dd/MM/yyyy)             | NOT NULL            |
| type  | TEXT    | Тип: "DAIRY" або "TOY"        | NOT NULL            |

---

### 📝 Приклад даних (автозаповнення):

**Молочні продукти (12 записів):**
```
┌────┬──────────────────────┬────────┬────────────┬────────┐
│ id │        name          │ price  │    date    │  type  │
├────┼──────────────────────┼────────┼────────────┼────────┤
│ 1  │ Milk 2.5%            │ 35.50  │ 01/11/2025 │ DAIRY  │
│ 2  │ Milk 3.2%            │ 38.00  │ 02/11/2025 │ DAIRY  │
│ 3  │ Yogurt Strawberry    │ 28.00  │ 03/11/2025 │ DAIRY  │
│ 4  │ Yogurt Natural       │ 25.50  │ 04/11/2025 │ DAIRY  │
│ 5  │ Kefir                │ 32.00  │ 05/11/2025 │ DAIRY  │
│ 6  │ Cottage Cheese       │ 45.00  │ 06/11/2025 │ DAIRY  │
│ 7  │ Sour Cream           │ 40.00  │ 07/11/2025 │ DAIRY  │
│ 8  │ Butter               │ 85.00  │ 08/11/2025 │ DAIRY  │
│ 9  │ Cream Milk           │ 55.00  │ 09/11/2025 │ DAIRY  │
│ 10 │ Cheese Gouda         │ 120.00 │ 10/11/2025 │ DAIRY  │
│ 11 │ Milk Chocolate       │ 42.00  │ 11/11/2025 │ DAIRY  │
│ 12 │ Milk Shake           │ 50.00  │ 12/11/2025 │ DAIRY  │
└────┴──────────────────────┴────────┴────────────┴────────┘
```

**Іграшки (12 записів):**
```
┌────┬──────────────────────┬────────┬────────────┬────────┐
│ id │        name          │ price  │    date    │  type  │
├────┼──────────────────────┼────────┼────────────┼────────┤
│ 13 │ Teddy Bear           │ 250.00 │ 15/11/2025 │ TOY    │
│ 14 │ Lego Castle          │ 450.00 │ 16/11/2025 │ TOY    │
│ 15 │ Barbie Doll          │ 180.00 │ 17/11/2025 │ TOY    │
│ 16 │ Hot Wheels Car       │ 120.00 │ 18/11/2025 │ TOY    │
│ 17 │ Puzzle 1000 pieces   │ 220.00 │ 19/11/2025 │ TOY    │
│ 18 │ Board Game Monopoly  │ 380.00 │ 20/11/2025 │ TOY    │
│ 19 │ Robot Transformer    │ 550.00 │ 21/11/2025 │ TOY    │
│ 20 │ Soft Bunny           │ 200.00 │ 22/11/2025 │ TOY    │
│ 21 │ Construction Set     │ 420.00 │ 23/11/2025 │ TOY    │
│ 22 │ Action Figure        │ 350.00 │ 24/11/2025 │ TOY    │
│ 23 │ Doll House           │ 680.00 │ 25/11/2025 │ TOY    │
│ 24 │ RC Helicopter        │ 890.00 │ 26/11/2025 │ TOY    │
└────┴──────────────────────┴────────┴────────────┴────────┘
```

**Всього: 24 записи** (12 DAIRY + 12 TOY) ✅

---

## 🔄 Повний потік даних

```
┌─────────────────────────────────────────────────────────────┐
│ 1. ЗАПУСК ДОДАТКА                                           │
│    MainActivity.onCreate()                                   │
└──────────────────┬──────────────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────────────┐
│ 2. ІНІЦІАЛІЗАЦІЯ ROOM DATABASE                             │
│    val database = ProductDatabase.getDatabase(context)      │
│    • Створення або отримання Singleton інстансу             │
│    • Підключення до SQLite файлу "product_database"         │
└──────────────────┬──────────────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────────────┐
│ 3. СТВОРЕННЯ REPOSITORY і SERVICE                           │
│    val repository = RoomProductRepository(dao)              │
│    val service = ProductService(repository)                 │
└──────────────────┬──────────────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────────────┐
│ 4. ПІДПИСКА НА ЗМІНИ БД (Flow.collect)                     │
│    lifecycleScope.launch {                                  │
│      repository.getAll().collect { products ->              │
│        if (products.isEmpty()) {                            │
│          fillDatabaseWithSampleData() // 🆕 Автозаповнення │
│        }                                                    │
│        adapter = ProductAdapter(products)                   │
│      }                                                      │
│    }                                                        │
└──────────────────┬──────────────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────────────┐
│ 5. АВТОЗАПОВНЕННЯ БД (якщо порожня)                        │
│    • 12 молочних продуктів (містять "milk")                │
│    • 12 іграшок (без "milk")                               │
│    ProductService → Repository → DAO → SQLite               │
└──────────────────┬──────────────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────────────┐
│ 6. ДОДАВАННЯ НОВОГО ТОВАРУ (User Action)                   │
│    User вводить: name, price, date                         │
│    ↓                                                        │
│    btnAdd.onClick → lifecycleScope.launch {                │
│      service.addProduct(name, price, date)                 │
│    }                                                        │
└──────────────────┬──────────────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────────────┐
│ 7. ВАЛІДАЦІЯ (ProductService)                              │
│    • Перевірка порожніх полів                              │
│    • Перевірка коректності ціни (> 0)                      │
│    • Визначення типу: milk → DAIRY, інше → TOY             │
└──────────────────┬──────────────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────────────┐
│ 8. КОНВЕРТАЦІЯ (Product → ProductEntity)                   │
│    Converters.toEntity():                                   │
│    • Product (Domain) → ProductEntity (Room)                │
│    • Додає type: "DAIRY" або "TOY"                         │
└──────────────────┬──────────────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────────────┐
│ 9. ЗБЕРЕЖЕННЯ В БД (Room + Coroutine)                      │
│    suspend fun insertProduct(entity)                        │
│    ↓                                                        │
│    INSERT INTO products VALUES (...)                        │
│    💾 SQLite зберігає на диск                              │
└──────────────────┬──────────────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────────────┐
│ 10. АВТОМАТИЧНЕ ОНОВЛЕННЯ (Flow Emission)                  │
│     Room автоматично викликає Flow.emit()                  │
│     ↓                                                       │
│     getAllProducts() повертає оновлений список              │
└──────────────────┬──────────────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────────────┐
│ 11. КОНВЕРТАЦІЯ НАЗАД (ProductEntity → Product)            │
│     Converters.toProduct():                                 │
│     • DAIRY → DairyProduct                                  │
│     • TOY → Toy                                             │
└──────────────────┬──────────────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────────────┐
│ 12. ОНОВЛЕННЯ UI (Adapter)                                 │
│     adapter = ProductAdapter(products)                      │
│     listView.adapter = adapter                              │
│     📱 Список автоматично оновлюється!                     │
└─────────────────────────────────────────────────────────────┘
```

---

## 🚀 Використані технології

| Технологія | Версія | Призначення |
|-----------|--------|-------------|
| **Kotlin** | 1.9.0 | Основна мова програмування |
| **Room Database** | 2.6.1 | SQLite ORM для зберігання даних |
| **Kotlin Coroutines** | 1.7.3 | Асинхронне програмування |
| **Kotlin Flow** | - | Реактивні потоки даних |
| **Material Design 3** | 1.11.0 | UI компоненти (TextInputLayout, MaterialButton) |
| **Android Lifecycle** | 2.6.2 | lifecycleScope для корутин |
| **KSP** | 1.9.0-1.0.13 | Генерація коду Room |
| **Gradle** | 8.1.4 | Система збірки |

---

## 📦 Залежності (build.gradle.kts)

```kotlin
dependencies {
    // Room Database
    val roomVersion = "2.6.1"
    implementation("androidx.room:room-runtime:$roomVersion")
    implementation("androidx.room:room-ktx:$roomVersion")
    ksp("androidx.room:room-compiler:$roomVersion")
    
    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.7.3")
    
    // Lifecycle
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.6.2")
}
```

---

## 🧪 Тестування через Database Inspector

### Запуск Database Inspector:
1. Запустити додаток на емуляторі (API 26+)
2. В Android Studio: **View → Tool Windows → App Inspection**
3. Вкладка **Database Inspector**
4. Вибрати `com.example.lab4app`
5. Розгорнути `product_database` → `products`
6. Побачити всі 24+ записів в реальному часі! 📊

### SQL запити для перевірки:

```sql
-- Показати всі товари
SELECT * FROM products;

-- Кількість записів кожного типу
SELECT type, COUNT(*) as count FROM products GROUP BY type;

-- Молочні продукти (має бути 12+)
SELECT * FROM products WHERE type = 'DAIRY';

-- Іграшки (має бути 12+)
SELECT * FROM products WHERE type = 'TOY';

-- Товари дорожче 100 грн
SELECT * FROM products WHERE price > 100;

-- Середня ціна по типах
SELECT type, AVG(price) as avg_price FROM products GROUP BY type;

-- Топ-5 найдорожчих товарів
SELECT * FROM products ORDER BY price DESC LIMIT 5;
```

---

## 📋 Інструкція із запуску

### 1. Вимоги:
- Android Studio (рекомендовано: Giraffe або новіше)
- Android SDK API 26+
- Емулятор або фізичний пристрій

### 2. Запуск:
```bash
1. Відкрити проект в Android Studio
2. File → Sync Project with Gradle Files
3. Запустити додаток (▶ Run)
4. При першому запуску БД автоматично заповниться 24 записами
5. Перевірити через Database Inspector
```

### 3. Перевірка збереження даних:
```
1. Додати новий товар вручну
2. Закрити додаток
3. Знову відкрити додаток
4. Переконатися, що товар залишився ✅
```

---

## ✅ Переваги Room Database

| Переваг| Опис |
|---------|------|
| **Type Safety** | Помилки типів на етапі компіляції |
| **Compile-time SQL** | Перевірка SQL запитів при компіляції |
| **Less Boilerplate** | Мінімум шаблонного коду |
| **Reactive Queries** | Автоматичне оновлення UI через Flow |
| **Migration Support** | Легке оновлення структури БД |
| **Testing Support** | Зручне тестування через in-memory БД |
| **Coroutines Integration** | Природна інтеграція з корутинами |

---

## 📚 Висновки

### Реалізовано:
1. ✅ Повноцінний Android додаток з Room Database
2. ✅ **Автоматичне заповнення БД 24 записами** (12 DAIRY + 12 TOY)
3. ✅ Clean Architecture з 4 шарами
4. ✅ SOLID принципи (особливо Dependency Inversion)
5. ✅ Асинхронні операції через Coroutines + Flow
6. ✅ Автоматичне оновлення UI (реактивний підхід)
7. ✅ Постійне зберігання даних у SQLite

### Набуті навички:
- 🎓 Робота з Room Database (Entity, DAO, Database, Converters)
- 🎓 Асинхронне програмування (suspend, Coroutines)
- 🎓 Реактивне програмування (Flow, collect)
- 🎓 Архітектурні патерни (Repository, Clean Architecture)
- 🎓 Тестування БД через Database Inspector

---

## 👨‍💻 Автор

**Лабораторна робота 4** - Android Development  
**Дата:** Листопад 2025  
**Версія:** 1.0 (Room Database)

package com.example.lab4app.data

import com.example.lab4app.model.Product
import kotlinx.coroutines.flow.Flow

interface ProductRepository {
    fun getAll(): Flow<List<Product>>
    suspend fun add(product: Product)
    suspend fun clear()
}
package com.example.lab4app.model

open class Product(
    val name: String,
    val price: Double,
    val date: String
)

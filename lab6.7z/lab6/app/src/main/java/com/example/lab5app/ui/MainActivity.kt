package com.example.lab4app.ui

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.lifecycle.lifecycleScope
import com.example.lab4app.R
import com.example.lab4app.adapter.ProductAdapter
import com.example.lab4app.data.RoomProductRepository
import com.example.lab4app.data.room.ProductDatabase
import com.example.lab4app.domain.ProductService
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.launch
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var service: ProductService
    private lateinit var adapter: ProductAdapter
    private lateinit var lv: ListView
    private lateinit var repository: RoomProductRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Ініціалізація Room Database
        val database = ProductDatabase.getDatabase(applicationContext)
        repository = RoomProductRepository(database.productDao())
        service = ProductService(repository)

        val tilName = findViewById<TextInputLayout>(R.id.tilName)
        val tilPrice = findViewById<TextInputLayout>(R.id.tilPrice)
        val etName = findViewById<TextInputEditText>(R.id.etName)
        val etPrice = findViewById<TextInputEditText>(R.id.etPrice)
        val etDate = findViewById<TextInputEditText>(R.id.etDate)
        val btnAdd = findViewById<MaterialButton>(R.id.btnAdd)
        val btnClear = findViewById<MaterialButton>(R.id.btnClear)
        lv = findViewById<ListView>(R.id.lvProducts)

        // 🆕 АВТОЗАПОВНЕННЯ БД при першому запуску
        lifecycleScope.launch {
            repository.getAll().collect { products ->
                // Якщо БД порожня - заповнюємо тестовими даними
                if (products.isEmpty()) {
                    fillDatabaseWithSampleData()
                }

                // Оновлюємо UI
                adapter = ProductAdapter(this@MainActivity, products)
                lv.adapter = adapter
            }
        }

        ViewCompat.setTooltipText(etDate, "Tap to pick a date")

        etDate.setOnClickListener {
            val c = Calendar.getInstance()
            DatePickerDialog(
                this,
                { _, year, month, day ->
                    etDate.setText("$day/${month + 1}/$year")
                },
                c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        btnAdd.setOnClickListener {
            tilName.error = null
            tilPrice.error = null

            val name = etName.text.toString()
            val price = etPrice.text.toString()
            val date = etDate.text.toString()

            lifecycleScope.launch {
                if (!service.addProduct(name, price, date)) {
                    if (name.isBlank()) tilName.error = "Enter name"
                    if (price.isBlank()) tilPrice.error = "Enter valid price"
                    Toast.makeText(this@MainActivity, "Invalid data", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@MainActivity, "Product added!", Toast.LENGTH_SHORT).show()
                    etName.text?.clear()
                    etPrice.text?.clear()
                    etDate.text?.clear()
                }
            }
        }

        btnClear.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Clear all?")
                .setMessage("Do you really want to clear all products?")
                .setPositiveButton("Yes") { _, _ ->
                    lifecycleScope.launch {
                        service.clear()
                        Toast.makeText(this@MainActivity, "All products cleared", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("No", null)
                .show()
        }
    }

    // 🆕 Функція автоматичного заповнення БД
    private suspend fun fillDatabaseWithSampleData() {
        val dairyProducts = listOf(
            Triple("Milk 2.5%", 35.50, "01/11/2025"),
            Triple("Milk 3.2%", 38.00, "02/11/2025"),
            Triple("Yogurt Strawberry", 28.00, "03/11/2025"),
            Triple("Yogurt Natural", 25.50, "04/11/2025"),
            Triple("Kefir", 32.00, "05/11/2025"),
            Triple("Cottage Cheese", 45.00, "06/11/2025"),
            Triple("Sour Cream", 40.00, "07/11/2025"),
            Triple("Butter", 85.00, "08/11/2025"),
            Triple("Cream Milk", 55.00, "09/11/2025"),
            Triple("Cheese Gouda", 120.00, "10/11/2025"),
            Triple("Milk Chocolate", 42.00, "11/11/2025"),
            Triple("Milk Shake", 50.00, "12/11/2025")
        )

        val toys = listOf(
            Triple("Teddy Bear", 250.00, "15/11/2025"),
            Triple("Lego Castle", 450.00, "16/11/2025"),
            Triple("Barbie Doll", 180.00, "17/11/2025"),
            Triple("Hot Wheels Car", 120.00, "18/11/2025"),
            Triple("Puzzle 1000 pieces", 220.00, "19/11/2025"),
            Triple("Board Game Monopoly", 380.00, "20/11/2025"),
            Triple("Robot Transformer", 550.00, "21/11/2025"),
            Triple("Soft Bunny", 200.00, "22/11/2025"),
            Triple("Construction Set", 420.00, "23/11/2025"),
            Triple("Action Figure Superman", 350.00, "24/11/2025"),
            Triple("Doll House", 680.00, "25/11/2025"),
            Triple("RC Helicopter", 890.00, "26/11/2025")
        )

        // Додаємо Dairy Products
        dairyProducts.forEach { (name, price, date) ->
            service.addProduct(name, price.toString(), date)
        }

        // Додаємо Toys
        toys.forEach { (name, price, date) ->
            service.addProduct(name, price.toString(), date)
        }
    }
}
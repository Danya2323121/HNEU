package com.example.lab4app.model

class DairyProduct(name: String, price: Double, date: String) : Product(name, price, date)

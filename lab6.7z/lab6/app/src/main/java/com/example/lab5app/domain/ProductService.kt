package com.example.lab4app.domain

import com.example.lab4app.data.ProductRepository
import com.example.lab4app.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class ProductService(private val repository: ProductRepository) {

    suspend fun addProduct(name: String, price: String, date: String): Boolean {
        if (name.isBlank() || price.isBlank() || date.isBlank()) return false
        val parsedPrice = price.toDoubleOrNull() ?: return false
        if (parsedPrice <= 0) return false

        val product = if (name.contains("milk", true))
            DairyProduct(name, parsedPrice, date)
        else
            Toy(name, parsedPrice, date)

        repository.add(product)
        return true
    }

    fun getAll(): Flow<List<Product>> = repository.getAll()

    suspend fun clear() = repository.clear()  
}
package com.example.lab4app.data.room

import com.example.lab4app.model.DairyProduct
import com.example.lab4app.model.Product
import com.example.lab4app.model.Toy

// Конвертація з Product моделі в ProductEntity
fun Product.toEntity(): ProductEntity {
    return ProductEntity(
        id = 0,  // Room автоматично згенерує ID
        name = this.name,
        price = this.price,
        date = this.date,
        type = when (this) {
            is DairyProduct -> "DAIRY"
            is Toy -> "TOY"
            else -> "OTHER"
        }
    )
}

// Конвертація з ProductEntity в Product модель
fun ProductEntity.toProduct(): Product {
    return when (this.type) {
        "DAIRY" -> DairyProduct(this.name, this.price, this.date)
        "TOY" -> Toy(this.name, this.price, this.date)
        else -> Toy(this.name, this.price, this.date)  // за замовчуванням
    }
}
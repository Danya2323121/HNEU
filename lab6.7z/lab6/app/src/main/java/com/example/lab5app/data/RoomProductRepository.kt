package com.example.lab4app.data

import com.example.lab4app.data.room.ProductDao
import com.example.lab4app.data.room.toEntity
import com.example.lab4app.data.room.toProduct
import com.example.lab4app.model.Product
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class RoomProductRepository(private val dao: ProductDao) : ProductRepository {

    override fun getAll(): Flow<List<Product>> {
        return dao.getAllProducts().map { entities ->
            entities.map { it.toProduct() }
        }
    }

    override suspend fun add(product: Product) {
        dao.insertProduct(product.toEntity())
    }

    override suspend fun clear() {
        dao.deleteAll()
    }
}
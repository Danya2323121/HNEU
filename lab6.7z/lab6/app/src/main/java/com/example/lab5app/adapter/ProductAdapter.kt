package com.example.lab4app.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.BaseAdapter
import com.example.lab4app.R
import com.example.lab4app.model.Product

class ProductAdapter(private val context: Context, private val products: List<Product>) : BaseAdapter() {
    override fun getCount() = products.size
    override fun getItem(position: Int) = products[position]
    override fun getItemId(position: Int) = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_product, parent, false)
        val product = getItem(position)

        view.findViewById<TextView>(R.id.tvName).text = product.name
        view.findViewById<TextView>(R.id.tvPrice).text = "Price: ${product.price}"
        view.findViewById<TextView>(R.id.tvDate).text = "Date: ${product.date}"

        return view
    }
}

package com.example.lab4app.model

class Toy(name: String, price: Double, date: String) : Product(name, price, date)

package com.example.lab4app.data

import com.example.lab4app.model.Product

object InMemoryProductRepository : ProductRepository {
    private val products = mutableListOf<Product>()

    override fun getAll(): List<Product> = products

    override fun add(product: Product) {
        products.add(product)
    }

    override fun clear() {
        products.clear()
    }
}

# OOP Kotlin Lab — Variant 9


## Опис
Простий демонстраційний проєкт для лабораторної роботи по ООП у Kotlin (варіант 9): іграшка, товар, продукт, молочний продукт.


Мета: показати роботу з абстрактними класами, інтерфейсами, спадкуванням і поліморфізмом.


## Файли
- `src/main/kotlin/lab/model/Product.kt` — абстрактний клас Product.
- `src/main/kotlin/lab/model/Sellable.kt` — інтерфейс Sellable.
- `src/main/kotlin/lab/model/Perishable.kt` — інтерфейс Perishable.
- `src/main/kotlin/lab/model/Toy.kt` — клас Toy.
- `src/main/kotlin/lab/model/FoodProduct.kt` — абстрактний клас для харчових продуктів.
- `src/main/kotlin/lab/model/DairyProduct.kt` — клас молочного продукту.
- `src/main/kotlin/lab/Main.kt` — приклад запуску і демонстрація.
- `plantuml/class_diagram.puml` — PlantUML-діаграма класів.


## Як запустити
### Опція A — за допомогою kotlinc
2. З папки `src/main/kotlin` компілюйте:
```bash
kotlinc -d out src/main/kotlin/lab/**/*.kt
kotlin -cp out lab.MainKt

```

## Що я зробив


Я підготував:
- Повний приклад коду для ієрархії класів.
- PlantUML-діаграму класів.
- README з інструкцією та структурою.


Ви бачите весь матеріал у цьому документі — копіюйте файли в свій проєкт і запускайте.


---


Якщо хочете, можу:


- Згенерувати `build.gradle.kts` (залежності, конфігурація `application`).
- Зробити варіант з JSON-серіалізацією/десеріалізацією (наприклад, kotlinx.serialization).
- Додати юніт-тести (JUnit).


Напишіть, що з цього бажаєте — я додам у наступній версії документа.
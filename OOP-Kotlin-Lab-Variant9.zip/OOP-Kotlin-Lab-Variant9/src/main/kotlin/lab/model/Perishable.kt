package lab.model


import java.time.LocalDate


interface Perishable {
    val expirationDate: LocalDate
}
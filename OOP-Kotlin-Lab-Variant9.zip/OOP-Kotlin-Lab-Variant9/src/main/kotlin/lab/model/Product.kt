package lab.model


abstract class Product(
    open var id: Int,
    open val name: String,
    open val price: Double
) {
    abstract fun info(): String
    abstract val _price: Double
        get()
}

package lab.model


/** Інтерфейс для об'єктів, що можна продавати */
interface Sellable {
    fun getPrice(): Double
    fun getDisplayName(): String
}
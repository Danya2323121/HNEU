package lab.model


import java.time.LocalDate


abstract class FoodProduct(
    override var id: Int,
    override val name: String,
    override val price: Double,
    override val expirationDate: LocalDate
) : Product(id, name, price), Sellable, Perishable {


    override fun info(): String = "FoodProduct(id=$id, name='$name', price=$price, expires=$expirationDate)"


    override fun getPrice(): Double = price
    override fun getDisplayName(): String = "Food: $name"
}
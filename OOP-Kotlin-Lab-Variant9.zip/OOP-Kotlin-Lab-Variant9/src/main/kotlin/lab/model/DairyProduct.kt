package lab.model


import java.time.LocalDate


class DairyProduct : FoodProduct {


    override val id: Int
    override val name: String
    override val price: Double
    override val expirationDate: LocalDate
    val fatPercentage: Double
    val volumeMl: Int

    constructor(
        id: Int,
        name: String,
        price: Double,
        expirationDate: LocalDate,
        fatPercentage: Double,
        volumeMl: Int
    ) : super(id, name, price, expirationDate) {
        this.id = id
        this.name = name
        this.price = price
        this.expirationDate = expirationDate
        this.fatPercentage = fatPercentage
        this.volumeMl = volumeMl
    }

    override fun info(): String =
        "DairyProduct(id=$id, name='$name', fat=${fatPercentage}%, volume=${volumeMl}ml, price=$price, expires=$expirationDate)"

    override fun getDisplayName(): String {
        TODO("Not yet implemented")
    }
}
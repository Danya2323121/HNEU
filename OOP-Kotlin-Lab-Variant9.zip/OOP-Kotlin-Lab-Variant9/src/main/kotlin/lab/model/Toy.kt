package lab.model


class Toy(
    override val id: Int,
    override val name: String,
    override val price: Double,
    val recommendedAge: Int,
    val material: String
) : Product(id, name, price), Sellable {


    override fun info(): String = "Toy(id=$id, name='$name', age+$recommendedAge, material=$material, price=$price)"


    override fun getPrice(): Double = price
    override fun getDisplayName(): String {
        TODO("Not yet implemented")
    }
}
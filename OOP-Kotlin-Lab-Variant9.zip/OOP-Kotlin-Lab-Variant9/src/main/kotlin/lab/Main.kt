package lab

import lab.model.*
import java.time.LocalDate

fun main() {
    val items: List<Sellable> = listOf(
        Toy(1, "Wooden Train", 499.0, recommendedAge = 3, material = "Wood"),
        DairyProduct(2, "Cow's Milk", 29.5, LocalDate.now().plusDays(7), fatPercentage = 3.2, volumeMl = 1000),
        DairyProduct(3, "Yogurt Strawberry", 15.0, LocalDate.now().minusDays(1), fatPercentage = 2.5, volumeMl = 200)
    )

    println("=== Product list ===")
    for (item in items) {
        println("${item.getDisplayName()} — price: ${item.getPrice()}")

        if (item is Product) {
            println(item.info())
        }

        if (item is Perishable) {
            val expired = if (item.expirationDate.isBefore(LocalDate.now())) "Yes" else "No"
            println("Expired: $expired")
        }

        println()
    }
}

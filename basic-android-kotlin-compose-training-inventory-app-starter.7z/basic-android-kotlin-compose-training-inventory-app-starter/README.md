# Лабораторна робота 5: Збереження даних за допомогою Room

**Виконав:** [Ваше ім'я]  
**Група:** [Ваша група]  
**Дата:** 26.11.2025

---

## Зміст
1. [Огляд проекту](#огляд-проекту)
2. [Завдання 1: Persist data with Room](#завдання-1-persist-data-with-room)
3. [Завдання 2: Read and update data using Room](#завдання-2-read-and-update-data-using-room)
4. [Архітектура додатку](#архітектура-додатку)
5. [Схеми](#схеми)
6. [Висновки](#висновки)

---

## Огляд проекту

**Назва:** Inventory App  
**Опис:** Додаток для відстеження інвентаря з локальною базою даних Room

### Що вже є в стартовому коді:
- ✅ UI екрани (HomeScreen, ItemEntryScreen, ItemDetailsScreen, ItemEditScreen)
- ✅ Navigation між екранами
- ✅ ViewModels (без реалізації Room)
- ✅ Базові класи Repository та Entity (порожні)
- ✅ Dependency Injection Container

### Що потрібно реалізувати:
- ❌ Room Database
- ❌ Entity з анотаціями
- ❌ DAO (Data Access Object)
- ❌ Repository implementation
- ❌ Підключити Room до ViewModels
- ❌ CRUD операції (Create, Read, Update, Delete)

### Технології
- **Android Jetpack Compose** - сучасний UI
- **Room Database 2.6.0** - локальна БД
- **ViewModel** - управління станом
- **Kotlin Flow & StateFlow** - реактивні дані
- **Kotlin Coroutines** - асинхронність
- **Navigation Compose** - навігація

---

## Завдання 1: Persist data with Room

### Мета
Додати Room Database до проекту та реалізувати збереження даних.

---

### Крок 1.1: Додати залежності Room

**Файл:** `app/build.gradle.kts`

**ЩО РОБИТИ:** Додати Room dependencies в секцію `dependencies`

```kotlin
dependencies {
    // Існуючі залежності...
    
    // Room - ДОДАТИ ЦІ РЯДКИ
    implementation("androidx.room:room-runtime:${rootProject.extra["room_version"]}")
    ksp("androidx.room:room-compiler:${rootProject.extra["room_version"]}")
    implementation("androidx.room:room-ktx:${rootProject.extra["room_version"]}")
}
```

---

### Крок 1.2: Створити Entity клас

**Файл:** `app/src/main/java/com/example/inventory/data/Item.kt`

**ЩО РОБИТИ:** Змінити існуючий клас, додавши Room анотації

**БУЛО:**
```kotlin
class Item(
    val id: Int = 0,
    val name: String,
    val price: Double,
    val quantity: Int
)
```

**СТАЛО:**
```kotlin
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "items")
data class Item(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val name: String,
    val price: Double,
    val quantity: Int
)
```

**Пояснення:**
- `@Entity(tableName = "items")` - позначає клас як таблицю БД з назвою "items"
- `@PrimaryKey(autoGenerate = true)` - автоматична генерація ID
- Змінили `class` на `data class` для зручності

---

### Крок 1.3: Створити DAO (Data Access Object)

**Файл:** `app/src/main/java/com/example/inventory/data/ItemDao.kt` (НОВИЙ ФАЙЛ)

**ЩО РОБИТИ:** Створити новий файл в папці `data`

```kotlin
package com.example.inventory.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ItemDao {
    
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(item: Item)
    
    @Update
    suspend fun update(item: Item)
    
    @Delete
    suspend fun delete(item: Item)
    
    @Query("SELECT * from items WHERE id = :id")
    fun getItem(id: Int): Flow<Item>
    
    @Query("SELECT * from items ORDER BY name ASC")
    fun getAllItems(): Flow<List<Item>>
}
```

**Пояснення:**
- `@Dao` - позначає інтерфейс як Data Access Object
- `suspend` - функції виконуються асинхронно
- `Flow<>` - реактивний потік для автоматичного оновлення UI
- SQL запити перевіряються на етапі компіляції

---

### Крок 1.4: Створити Database клас

**Файл:** `app/src/main/java/com/example/inventory/data/InventoryDatabase.kt` (НОВИЙ ФАЙЛ)

**ЩО РОБИТИ:** Створити новий файл в папці `data`

```kotlin
package com.example.inventory.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Item::class], version = 1, exportSchema = false)
abstract class InventoryDatabase : RoomDatabase() {

    abstract fun itemDao(): ItemDao

    companion object {
        @Volatile
        private var Instance: InventoryDatabase? = null

        fun getDatabase(context: Context): InventoryDatabase {
            return Instance ?: synchronized(this) {
                Room.databaseBuilder(
                    context,
                    InventoryDatabase::class.java,
                    "item_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { Instance = it }
            }
        }
    }
}
```

**Пояснення:**
- `@Database` - позначає клас як Room Database
- `entities = [Item::class]` - список таблиць
- `version = 1` - версія БД
- Singleton pattern - один екземпляр БД на весь додаток
- `@Volatile` - видимість між потоками
- `synchronized` - запобігає створенню кількох екземплярів

---

### Крок 1.5: Реалізувати Repository

**Файл:** `app/src/main/java/com/example/inventory/data/ItemsRepository.kt`

**ЩО РОБИТИ:** Додати методи в інтерфейс

**БУЛО:**
```kotlin
interface ItemsRepository
```

**СТАЛО:**
```kotlin
package com.example.inventory.data

import kotlinx.coroutines.flow.Flow

interface ItemsRepository {
    fun getAllItemsStream(): Flow<List<Item>>
    
    fun getItemStream(id: Int): Flow<Item?>
    
    suspend fun insertItem(item: Item)
    
    suspend fun deleteItem(item: Item)
    
    suspend fun updateItem(item: Item)
}
```

---

### Крок 1.6: Реалізувати OfflineItemsRepository

**Файл:** `app/src/main/java/com/example/inventory/data/OfflineItemsRepository.kt`

**ЩО РОБИТИ:** Змінити клас, додавши реалізацію

**БУЛО:**
```kotlin
class OfflineItemsRepository : ItemsRepository
```

**СТАЛО:**
```kotlin
package com.example.inventory.data

import kotlinx.coroutines.flow.Flow

class OfflineItemsRepository(private val itemDao: ItemDao) : ItemsRepository {
    
    override fun getAllItemsStream(): Flow<List<Item>> = itemDao.getAllItems()
    
    override fun getItemStream(id: Int): Flow<Item?> = itemDao.getItem(id)
    
    override suspend fun insertItem(item: Item) = itemDao.insert(item)
    
    override suspend fun deleteItem(item: Item) = itemDao.delete(item)
    
    override suspend fun updateItem(item: Item) = itemDao.update(item)
}
```

**Пояснення:**
- Реалізує всі методи з інтерфейсу
- Делегує виклики до ItemDao
- Repository Pattern - абстрагує джерело даних

---

### Крок 1.7: Оновити AppDataContainer

**Файл:** `app/src/main/java/com/example/inventory/data/AppContainer.kt`

**ЩО РОБИТИ:** Змінити реалізацію, додавши Database

**БУЛО:**
```kotlin
override val itemsRepository: ItemsRepository by lazy {
    OfflineItemsRepository()
}
```

**СТАЛО:**
```kotlin
package com.example.inventory.data

import android.content.Context

interface AppContainer {
    val itemsRepository: ItemsRepository
}

class AppDataContainer(private val context: Context) : AppContainer {
    override val itemsRepository: ItemsRepository by lazy {
        OfflineItemsRepository(InventoryDatabase.getDatabase(context).itemDao())
    }
}
```

**Пояснення:**
- Створюємо екземпляр БД через `getDatabase(context)`
- Отримуємо DAO через `itemDao()`
- Передаємо DAO в Repository

---

## Завдання 2: Read and update data using Room

### Мета
Підключити ViewModels до Repository та реалізувати CRUD операції.

---

### Крок 2.1: Оновити HomeViewModel

**Файл:** `app/src/main/java/com/example/inventory/ui/home/HomeViewModel.kt`

**ЩО РОБИТИ:** Додати отримання даних з Repository

**БУЛО:**
```kotlin
class HomeViewModel : ViewModel() {
    companion object {
        private const val TIMEOUT_MILLIS = 5_000L
    }
}

data class HomeUiState(val itemList: List<Item> = listOf())
```

**СТАЛО:**
```kotlin
package com.example.inventory.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.inventory.data.Item
import com.example.inventory.data.ItemsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

class HomeViewModel(private val itemsRepository: ItemsRepository) : ViewModel() {

    val homeUiState: StateFlow<HomeUiState> = itemsRepository.getAllItemsStream()
        .map { HomeUiState(it) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(TIMEOUT_MILLIS),
            initialValue = HomeUiState()
        )

    companion object {
        private const val TIMEOUT_MILLIS = 5_000L
    }
}

data class HomeUiState(val itemList: List<Item> = listOf())
```

**Пояснення:**
- Додали параметр `itemsRepository` в конструктор
- `getAllItemsStream()` - отримуємо Flow з БД
- `.map { HomeUiState(it) }` - перетворюємо в UI state
- `.stateIn()` - конвертуємо Flow в StateFlow для Compose

---

### Крок 2.2: Оновити HomeScreen

**Файл:** `app/src/main/java/com/example/inventory/ui/home/HomeScreen.kt`

**ЩО РОБИТИ:** Підключити ViewModel та відображати дані

**ЗНАЙТИ:**
```kotlin
@Composable
fun HomeScreen(
    navigateToItemEntry: () -> Unit,
    navigateToItemUpdate: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
```

**ДОДАТИ ПІСЛЯ ПАРАМЕТРІВ:**
```kotlin
@Composable
fun HomeScreen(
    navigateToItemEntry: () -> Unit,
    navigateToItemUpdate: (Int) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: HomeViewModel = viewModel(factory = AppViewModelProvider.Factory)
) {
```

**ЗНАЙТИ:**
```kotlin
HomeBody(
    itemList = listOf(),
    onItemClick = navigateToItemUpdate,
```

**ЗАМІНИТИ НА:**
```kotlin
val homeUiState by viewModel.homeUiState.collectAsState()

HomeBody(
    itemList = homeUiState.itemList,
    onItemClick = navigateToItemUpdate,
```

**ДОДАТИ ІМПОРТИ:**
```kotlin
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.inventory.ui.AppViewModelProvider
```

---

### Крок 2.3: Оновити ItemEntryViewModel

**Файл:** `app/src/main/java/com/example/inventory/ui/item/ItemEntryViewModel.kt`

**ЩО РОБИТИ:** Додати збереження в БД

**ДОДАТИ В КЛАС:**
```kotlin
class ItemEntryViewModel(private val itemsRepository: ItemsRepository) : ViewModel() {

    var itemUiState by mutableStateOf(ItemUiState())
        private set

    fun updateUiState(itemDetails: ItemDetails) {
        itemUiState =
            ItemUiState(itemDetails = itemDetails, isEntryValid = validateInput(itemDetails))
    }

    // ДОДАТИ ЦЮ ФУНКЦІЮ:
    suspend fun saveItem() {
        if (validateInput()) {
            itemsRepository.insertItem(itemUiState.itemDetails.toItem())
        }
    }

    private fun validateInput(uiState: ItemDetails = itemUiState.itemDetails): Boolean {
        return with(uiState) {
            name.isNotBlank() && price.isNotBlank() && quantity.isNotBlank()
        }
    }
}
```

---

### Крок 2.4: Оновити ItemEntryScreen

**Файл:** `app/src/main/java/com/example/inventory/ui/item/ItemEntryScreen.kt`

**ЩО РОБИТИ:** Додати збереження при натисканні кнопки

**ЗНАЙТИ:**
```kotlin
ItemEntryBody(
    itemUiState = viewModel.itemUiState,
    onItemValueChange = viewModel::updateUiState,
    onSaveClick = { },
```

**ЗАМІНИТИ НА:**
```kotlin
val coroutineScope = rememberCoroutineScope()

ItemEntryBody(
    itemUiState = viewModel.itemUiState,
    onItemValueChange = viewModel::updateUiState,
    onSaveClick = {
        coroutineScope.launch {
            viewModel.saveItem()
            navigateBack()
        }
    },
```

**ДОДАТИ ІМПОРТИ:**
```kotlin
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
```

---

### Крок 2.5: Оновити ItemDetailsViewModel

**Файл:** `app/src/main/java/com/example/inventory/ui/item/ItemDetailsViewModel.kt`

**ЩО РОБИТИ:** Додати отримання, оновлення та видалення

**БУЛО:**
```kotlin
class ItemDetailsViewModel(
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val itemId: Int = checkNotNull(savedStateHandle[ItemDetailsDestination.itemIdArg])

    companion object {
        private const val TIMEOUT_MILLIS = 5_000L
    }
}
```

**СТАЛО:**
```kotlin
package com.example.inventory.ui.item

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.inventory.data.ItemsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

class ItemDetailsViewModel(
    savedStateHandle: SavedStateHandle,
    private val itemsRepository: ItemsRepository
) : ViewModel() {

    private val itemId: Int = checkNotNull(savedStateHandle[ItemDetailsDestination.itemIdArg])

    val uiState: StateFlow<ItemDetailsUiState> = itemsRepository.getItemStream(itemId)
        .filterNotNull()
        .map {
            ItemDetailsUiState(outOfStock = it.quantity <= 0, itemDetails = it.toItemDetails())
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(TIMEOUT_MILLIS),
            initialValue = ItemDetailsUiState()
        )

    suspend fun reduceQuantityByOne() {
        val currentItem = uiState.value.itemDetails.toItem()
        if (currentItem.quantity > 0) {
            itemsRepository.updateItem(currentItem.copy(quantity = currentItem.quantity - 1))
        }
    }

    suspend fun deleteItem() {
        itemsRepository.deleteItem(uiState.value.itemDetails.toItem())
    }

    companion object {
        private const val TIMEOUT_MILLIS = 5_000L
    }
}

data class ItemDetailsUiState(
    val outOfStock: Boolean = true,
    val itemDetails: ItemDetails = ItemDetails()
)
```

---

### Крок 2.6: Оновити ItemDetailsScreen

**Файл:** `app/src/main/java/com/example/inventory/ui/item/ItemDetailsScreen.kt`

**ЩО РОБИТИ:** Підключити ViewModel та операції

**ЗНАЙТИ:**
```kotlin
@Composable
fun ItemDetailsScreen(
    navigateToEditItem: (Int) -> Unit,
    navigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
```

**ДОДАТИ:**
```kotlin
@Composable
fun ItemDetailsScreen(
    navigateToEditItem: (Int) -> Unit,
    navigateBack: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: ItemDetailsViewModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    val uiState by viewModel.uiState.collectAsState()
    val coroutineScope = rememberCoroutineScope()
```

**ЗАМІНИТИ:**
```kotlin
floatingActionButton = {
    FloatingActionButton(
        onClick = { navigateToEditItem(uiState.itemDetails.id) },
```

```kotlin
ItemDetailsBody(
    itemDetailsUiState = uiState,
    onSellItem = {
        coroutineScope.launch {
            viewModel.reduceQuantityByOne()
        }
    },
    onDelete = {
        coroutineScope.launch {
            viewModel.deleteItem()
            navigateBack()
        }
    },
```

**ДОДАТИ ІМПОРТИ:**
```kotlin
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.inventory.ui.AppViewModelProvider
import kotlinx.coroutines.launch
```

**ЗМІНИТИ В ItemDetailsBody:**
```kotlin
Button(
    onClick = onSellItem,
    modifier = Modifier.fillMaxWidth(),
    shape = MaterialTheme.shapes.small,
    enabled = !itemDetailsUiState.outOfStock  // ЗМІНИТИ enabled
) {
    Text(stringResource(R.string.sell))
}
```

---

### Крок 2.7: Оновити ItemEditViewModel

**Файл:** `app/src/main/java/com/example/inventory/ui/item/ItemEditViewModel.kt`

**ЩО РОБИТИ:** Додати завантаження та збереження

**БУЛО:**
```kotlin
class ItemEditViewModel(
    savedStateHandle: SavedStateHandle,
) : ViewModel() {

    var itemUiState by mutableStateOf(ItemUiState())
        private set

    private val itemId: Int = checkNotNull(savedStateHandle[ItemEditDestination.itemIdArg])

    private fun validateInput(uiState: ItemDetails = itemUiState.itemDetails): Boolean {
        return with(uiState) {
            name.isNotBlank() && price.isNotBlank() && quantity.isNotBlank()
        }
    }
}
```

**СТАЛО:**
```kotlin
package com.example.inventory.ui.item

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.inventory.data.ItemsRepository
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class ItemEditViewModel(
    savedStateHandle: SavedStateHandle,
    private val itemsRepository: ItemsRepository
) : ViewModel() {

    var itemUiState by mutableStateOf(ItemUiState())
        private set

    private val itemId: Int = checkNotNull(savedStateHandle[ItemEditDestination.itemIdArg])

    init {
        viewModelScope.launch {
            itemUiState = itemsRepository.getItemStream(itemId)
                .filterNotNull()
                .first()
                .toItemUiState(true)
        }
    }

    fun updateUiState(itemDetails: ItemDetails) {
        itemUiState =
            ItemUiState(itemDetails = itemDetails, isEntryValid = validateInput(itemDetails))
    }

    suspend fun updateItem() {
        if (validateInput(itemUiState.itemDetails)) {
            itemsRepository.updateItem(itemUiState.itemDetails.toItem())
        }
    }

    private fun validateInput(uiState: ItemDetails = itemUiState.itemDetails): Boolean {
        return with(uiState) {
            name.isNotBlank() && price.isNotBlank() && quantity.isNotBlank()
        }
    }
}
```

---

### Крок 2.8: Оновити ItemEditScreen

**Файл:** `app/src/main/java/com/example/inventory/ui/item/ItemEditScreen.kt`

**ЩО РОБИТИ:** Підключити збереження

**ЗАМІНИТИ:**
```kotlin
ItemEntryBody(
    itemUiState = viewModel.itemUiState,
    onItemValueChange = { },
    onSaveClick = { },
```

**НА:**
```kotlin
val coroutineScope = rememberCoroutineScope()

ItemEntryBody(
    itemUiState = viewModel.itemUiState,
    onItemValueChange = viewModel::updateUiState,
    onSaveClick = {
        coroutineScope.launch {
            viewModel.updateItem()
            navigateBack()
        }
    },
```

**ДОДАТИ ІМПОРТИ:**
```kotlin
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
```

---

### Крок 2.9: Оновити AppViewModelProvider

**Файл:** `app/src/main/java/com/example/inventory/ui/AppViewModelProvider.kt`

**ЩО РОБИТИ:** Передати Repository у ViewModels

**БУЛО:**
```kotlin
object AppViewModelProvider {
    val Factory = viewModelFactory {
        initializer {
            ItemEditViewModel(
                this.createSavedStateHandle()
            )
        }
        initializer {
            ItemEntryViewModel()
        }
        initializer {
            ItemDetailsViewModel(
                this.createSavedStateHandle()
            )
        }
        initializer {
            HomeViewModel()
        }
    }
}
```

**СТАЛО:**
```kotlin
package com.example.inventory.ui

import android.app.Application
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory
import androidx.lifecycle.createSavedStateHandle
import androidx.lifecycle.viewmodel.CreationExtras
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.inventory.InventoryApplication
import com.example.inventory.ui.home.HomeViewModel
import com.example.inventory.ui.item.ItemDetailsViewModel
import com.example.inventory.ui.item.ItemEditViewModel
import com.example.inventory.ui.item.ItemEntryViewModel

object AppViewModelProvider {
    val Factory = viewModelFactory {
        initializer {
            ItemEditViewModel(
                this.createSavedStateHandle(),
                inventoryApplication().container.itemsRepository
            )
        }
        initializer {
            ItemEntryViewModel(inventoryApplication().container.itemsRepository)
        }
        initializer {
            ItemDetailsViewModel(
                this.createSavedStateHandle(),
                inventoryApplication().container.itemsRepository
            )
        }
        initializer {
            HomeViewModel(inventoryApplication().container.itemsRepository)
        }
    }
}

fun CreationExtras.inventoryApplication(): InventoryApplication =
    (this[AndroidViewModelFactory.APPLICATION_KEY] as InventoryApplication)
